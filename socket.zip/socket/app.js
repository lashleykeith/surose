const express = require('express');
const { createServer } = require('node:http');
const { Server } = require('socket.io');

const app = express();
const server = createServer(app);
const io = new Server(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST'],
    },
});

io.on('connection', (socket) => {
    const query = socket.handshake.query;
    socket.join(query.room);

    socket.on('chat:create', (data) => {
        socket.broadcast.to(data.room).emit('chat:create', data);
    });
});

server.listen(5000, () => {
    console.log('server running at http://localhost:5000');
});